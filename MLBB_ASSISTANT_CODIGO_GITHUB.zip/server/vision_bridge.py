"""Extração de evidências visíveis usando um provedor opcional de visão online.

Não devolve builds: o modelo só transcreve sinais observáveis da captura.
Sem OPENAI_API_KEY + MLBB_VISION_ENABLED=1 não envia imagens a terceiros.
"""
from __future__ import annotations

import base64
import json
import os
from typing import Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field


class VisualState(BaseModel):
    model_config = ConfigDict(extra="forbid")
    screen_type: Literal["match_scoreboard", "match_gameplay", "shop", "post_match", "other"]
    self_hero: str | None
    enemies: list[str] = Field(max_length=5)
    owned_items: list[str] = Field(max_length=6)
    enemy_items: list[str] = Field(max_length=30)
    note: str = Field(max_length=180)


OUTPUT_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "properties": {
        "screen_type": {"type": "string", "enum": ["match_scoreboard", "match_gameplay", "shop", "post_match", "other"]},
        "self_hero": {"type": ["string", "null"]},
        "enemies": {"type": "array", "items": {"type": "string"}},
        "owned_items": {"type": "array", "items": {"type": "string"}},
        "enemy_items": {"type": "array", "items": {"type": "string"}},
        "note": {"type": "string"},
    },
    "required": ["screen_type", "self_hero", "enemies", "owned_items", "enemy_items", "note"],
}

PROMPT = """Você é APENAS um extrator de informações visuais de partidas de Mobile Legends Bang Bang.
Responda em JSON, sem recomendar builds, sem inventar heróis, itens, números ou situações.
Determine a tela:
- match_scoreboard: tabela de 10 jogadores aberta DURANTE a partida (placar no topo, gameplay ainda ativo).
- match_gameplay: mapa/personagem/controles de batalha visíveis, sem tabela completa.
- shop: loja de itens durante a partida.
- post_match: tela final de VICTORY/DEFEAT com estatísticas (NÃO é partida ao vivo).
- other: telas incertas, menu, capturas não relacionadas.
self_hero = herói do jogador somente se a captura permitir distinguir. Não confunda avatar e nome do jogador.
enemies = no máximo cinco HERÓIS que você consegue ler claramente do time inimigo.
owned_items = nomes de itens claramente equipados pelo jogador (NÃO sugestões da loja).
enemy_items = itens VISÍVEIS na tabela do time inimigo, sem deduzir pelos heróis.
Se o placar estiver fechado, normalmente deixe arrays de itens vazios.
Não leia sugestões de painéis flutuantes como evidência do próprio jogo.
Se a imagem estiver borrada/pequena, deixe nomes não confiáveis fora da lista.
note: frase curta em português indicando o que realmente está legível. Nunca escreva probabilidade/confiança numérica."""


def online_ready() -> bool:
    return os.getenv("MLBB_VISION_ENABLED", "0") == "1" and bool(os.getenv("OPENAI_API_KEY", ""))


async def read_visual_state(image: bytes, content_type: str = "image/jpeg") -> VisualState:
    """Chamada real a Responses API. Chave fica somente no servidor."""
    if not online_ready():
        raise RuntimeError("Visão online não configurada no servidor")
    model = os.getenv("MLBB_VISION_MODEL", "gpt-4.1-mini")
    payload = {
        "model": model,
        "store": False,
        "max_output_tokens": 850,
        "input": [{"role": "user", "content": [
            {"type": "input_text", "text": PROMPT},
            {"type": "input_image", "image_url": f"data:{content_type};base64,{base64.b64encode(image).decode('ascii')}", "detail": "high"},
        ]}],
        "text": {"format": {"type": "json_schema", "name": "mlbb_screen_observation", "strict": True, "schema": OUTPUT_SCHEMA}},
    }
    async with httpx.AsyncClient(timeout=httpx.Timeout(25.0, connect=5.0)) as client:
        response = await client.post(
            "https://api.openai.com/v1/responses", json=payload,
            headers={"Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
        )
        response.raise_for_status()
        body = response.json()
    for output in body.get("output", []):
        for content in output.get("content", []):
            if content.get("type") == "output_text":
                return VisualState.model_validate(json.loads(content["text"]))
    raise ValueError("Provedor não retornou observação visual estruturada")
