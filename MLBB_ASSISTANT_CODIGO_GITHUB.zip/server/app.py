"""MLBB ASSISTANT V0.3 — análise de imagens DURANTE a partida.

Se configurada, visão online extrai apenas evidências visuais; regras separadas sugerem itens.
Nenhuma captura é gravada. Não injeta código, não controla o jogo.
"""
from __future__ import annotations

import hmac
import json
import os
import threading
import time
from pathlib import Path
from uuid import UUID

import cv2
import numpy as np
from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field

import vision_bridge

ROOT = Path(__file__).parent
DB = json.loads((ROOT / "data.json").read_text(encoding="utf-8"))
TEMPLATES = ROOT / "templates"
app = FastAPI(title="MLBB Assistant", version="0.3.0")
ITEM_NAME = {name.casefold(): name for name in DB["items"]}
ITEM_ALIASES = {name.lower().replace(" ", "_"): name for name in DB["items"]}
# Somente itens de defesa FÍSICA — item mágico não comprova armadura.
PHYSICAL_ARMOR_ITEMS = {"antique cuirass", "blade armor", "dominance ice", "brute force breastplate", "twilight armor"}
SESSION_TTL = 10 * 60  # informações envelhecem; não manter dados da partida anterior.
SESSIONS: dict[str, dict] = {}
SESSIONS_LOCK = threading.RLock()


class MatchState(BaseModel):
    hero: str
    enemies: list[str] = Field(default_factory=list)
    enemy_armor_stacking: bool = False
    enemy_healing_high: bool = False
    enemy_magic_burst: bool = False
    owned_items: list[str] = Field(default_factory=list)


def require_authorization(request: Request, authorization: str | None = Header(default=None)) -> None:
    expected = os.environ.get("MLBB_API_TOKEN", "")
    if expected:
        if not hmac.compare_digest(authorization or "", f"Bearer {expected}"):
            raise HTTPException(status_code=401, detail="Token inválido")
    elif not request.client or request.client.host not in {"127.0.0.1", "::1", "testclient"}:
        raise HTTPException(status_code=403, detail="Defina MLBB_API_TOKEN para acesso pela rede")


def recommend(state: MatchState) -> dict:
    hero = DB["heroes"].get(state.hero.strip().lower())
    if hero is None:
        return {"hero": state.hero, "recommendations": [], "note": "Herói não cadastrado; nenhum item será inventado"}
    ranked = []
    owned = {item.strip().casefold() for item in state.owned_items}
    for item_name in hero["candidates"]:
        if item_name.casefold() in owned:
            continue
        item = DB["items"][item_name]
        score = item["base"]
        reasons = ["candidato do perfil demonstrativo de Hanzo"]
        for condition, bonus, reason in item["rules"]:
            if getattr(state, condition):
                score += bonus
                reasons.append(reason)
        ranked.append({"item": item_name, "score": score, "reason": "; ".join(reasons),
                       "source": "regras demonstrativas; patch não verificado"})
    ranked.sort(key=lambda c: (-c["score"], c["item"]))
    return {"hero": state.hero, "recommendations": ranked[:3],
            "note": "Os scores são pesos de regra, NÃO representam confiança de IA."}


def safe_parse_list(value: str) -> list[str]:
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list) and all(isinstance(x, str) for x in parsed) and len(parsed) <= 30:
            return [x[:60] for x in parsed]
    except (json.JSONDecodeError, TypeError):
        pass
    return []


def normal_names(names: list[str], max_items: int) -> list[str]:
    return list(dict.fromkeys(n.strip()[:60] for n in names if isinstance(n, str) and n.strip()))[:max_items]


def detect(frame: np.ndarray) -> list[dict]:
    """Matching local pré-existente, útil só quando templates reais são cadastrados."""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    found = []
    if not TEMPLATES.exists():
        return found
    for category in ("hero", "enemy", "owned_item"):
        for file in sorted((TEMPLATES / category).glob("*.png")):
            template = cv2.imread(str(file), cv2.IMREAD_GRAYSCALE)
            if template is None or min(template.shape) < 12 or np.std(template) < 12:
                continue
            best = None
            for scale in (0.85, 1.0, 1.15):
                resized = cv2.resize(template, None, fx=scale, fy=scale, interpolation=cv2.INTER_LINEAR)
                h, w = resized.shape
                if h >= gray.shape[0] or w >= gray.shape[1]:
                    continue
                response = cv2.matchTemplate(gray, resized, cv2.TM_CCOEFF_NORMED)
                _, similarity, _, location = cv2.minMaxLoc(response)
                if best is None or similarity > best[0]:
                    best = (similarity, location, w, h)
            if best and best[0] >= 0.93:
                similarity, location, w, h = best
                found.append({"category": category, "label": file.stem, "similarity": round(float(similarity), 3),
                              "box": [location[0], location[1], w, h]})
    return found


def get_session(session_id: str, now: float) -> dict:
    if not session_id:
        return {}
    try:
        UUID(session_id)
    except (ValueError, AttributeError):
        return {}
    with SESSIONS_LOCK:
        for sid in list(SESSIONS):
            if now - SESSIONS[sid]["last_seen"] > SESSION_TTL:
                del SESSIONS[sid]
        session = SESSIONS.get(session_id, {})
        session["last_seen"] = now
        SESSIONS[session_id] = session
        if len(SESSIONS) > 100:
            oldest = min(SESSIONS, key=lambda s: SESSIONS[s]["last_seen"])
            del SESSIONS[oldest]
        return dict(session)


def update_session(session_id: str, changes: dict) -> None:
    if not session_id or session_id not in SESSIONS or not changes:
        return
    with SESSIONS_LOCK:
        SESSIONS[session_id].update(changes)


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.3.0", "vision": "online" if vision_bridge.online_ready() else "templates",
            "templates": len(list(TEMPLATES.glob("*/*.png"))) if TEMPLATES.exists() else 0,
            "data_patch": "demonstrativo — NÃO verificado"}


@app.post("/recommend", dependencies=[Depends(require_authorization)])
def recommend_endpoint(state: MatchState):
    return recommend(state)


@app.post("/analyze", dependencies=[Depends(require_authorization)])
async def analyze(
    image: UploadFile = File(...),
    hero_hint: str = Form(default=""),
    session_id: str = Form(default=""),
    enemies: str = Form(default="[]"),
    owned_items: str = Form(default="[]"),
    enemy_armor_stacking: bool = Form(default=False),
    enemy_healing_high: bool = Form(default=False),
    enemy_magic_burst: bool = Form(default=False),
):
    if image.content_type not in ("image/jpeg", "image/png"):
        raise HTTPException(status_code=415, detail="Somente imagens JPG/PNG")
    data = await image.read(2_500_001)
    if len(data) > 2_500_000:
        raise HTTPException(status_code=413, detail="Máximo de 2,5 MB por imagem")
    frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        raise HTTPException(status_code=400, detail="Imagem inválida")
    if frame.shape[0] * frame.shape[1] > 4_000_000:
        raise HTTPException(status_code=413, detail="Imagem acima de 4 MP")
    now = time.monotonic()
    previous = get_session(session_id, now)
    observations = {}
    detections: list[dict] = []
    vision_status = "sem IA configurada (templates locais)"
    screen_type = "unknown"

    if vision_bridge.online_ready():
        try:
            visual = await vision_bridge.read_visual_state(data, image.content_type)
        except Exception:  # Nunca expõe credenciais, dados ou payload em mensagens ao celular.
            vision_status = "falha temporária da IA online; último estado pode estar desatualizado"
        else:
            screen_type = visual.screen_type
            vision_status = "IA online observou " + screen_type
            # Telas de resultado final NÃO alimentam análise durante partida.
            if screen_type in {"match_scoreboard", "shop", "match_gameplay"}:
                if visual.self_hero:
                    observations["hero"] = visual.self_hero.strip().lower()[:60]
                if screen_type == "match_scoreboard":
                    if visual.enemies:
                        observations["enemies"] = normal_names(visual.enemies, 5)
                    if visual.owned_items:
                        observations["owned_items"] = normal_names(visual.owned_items, 6)
                    if visual.enemy_items:
                        observations["enemy_items"] = normal_names(visual.enemy_items, 30)
                elif screen_type == "shop" and visual.owned_items:
                    observations["owned_items"] = normal_names(visual.owned_items, 6)
                if observations:
                    observations["visual_at"] = now
            else:
                # Nunca herdar a partida anterior se aparecer a tela final.
                if screen_type == "post_match":
                    update_session(session_id, {"hero": None, "enemies": [], "owned_items": [],
                                                "enemy_items": [], "visual_at": 0})
                    previous = {}
    else:
        detections = detect(frame)
        heroes = [d["label"] for d in detections if d["category"] == "hero"]
        if heroes:
            observations["hero"] = heroes[0]
            observations["visual_at"] = now
        enemies_detected = [d["label"] for d in detections if d["category"] == "enemy"]
        if enemies_detected:
            observations["enemies"] = normal_names(enemies_detected, 5)
            observations["visual_at"] = now
        owned_detected = [ITEM_ALIASES[d["label"]] for d in detections if d["category"] == "owned_item"
                          and d["label"] in ITEM_ALIASES]
        if owned_detected:
            observations["owned_items"] = normal_names(owned_detected, 6)
            observations["visual_at"] = now

    if screen_type == "post_match":
        return {"screen_type": screen_type, "vision_status": vision_status, "detections": detections,
                "extracted": {"hero": None, "enemies": [], "owned_items": [], "enemy_items": [],
                              "hero_source": "sem análise ao vivo"},
                "recommendation": None, "recommendations": [],
                "message": "Partida encerrada — não recomendamos itens no placar final",
                "warning": "Tela final descartada."}

    update_session(session_id, observations)
    merged = {**previous, **observations}
    cached = bool(previous.get("visual_at")) and not observations.get("visual_at")
    visual_age = round(now - merged["visual_at"]) if merged.get("visual_at") else None
    if visual_age is not None and visual_age > SESSION_TTL:
        merged = {}
        cached = False
    hero = str(merged.get("hero") or hero_hint.strip().lower())
    enemy_heroes = normal_names(list(merged.get("enemies", [])) + safe_parse_list(enemies), 5)
    equipped = normal_names(list(merged.get("owned_items", [])) + safe_parse_list(owned_items), 6)
    enemy_equipped = normal_names(list(merged.get("enemy_items", [])), 30)
    # Só detectar 'armadura acumulada' automaticamente quando houver >=2 evidências de itens físicos.
    physical_count = sum(1 for item in enemy_equipped if item.casefold() in PHYSICAL_ARMOR_ITEMS)
    state = MatchState(
        hero=hero, enemies=enemy_heroes, owned_items=equipped,
        enemy_armor_stacking=enemy_armor_stacking or physical_count >= 2,
        enemy_healing_high=enemy_healing_high, enemy_magic_burst=enemy_magic_burst,
    )
    ranked = recommend(state)
    best = ranked["recommendations"][0].copy() if ranked["recommendations"] else None
    source = "visual" if merged.get("hero") else "manual" if hero_hint else "desconhecido"
    if best:
        best["source"] = f"{source}; regras demonstrativas (patch não verificado)"
    if visual_age is not None and visual_age > 90:
        vision_status += "; observações antigas"
    if not best and hero and hero not in DB["heroes"]:
        message = "Herói reconhecido, mas ainda sem perfil de builds cadastrado"
    elif not merged.get("visual_at"):
        message = "Sem evidência visual de heróis/itens: recomendação, se houver, é apenas ilustrativa"
    elif cached:
        message = "Usando últimas observações visuais da partida"
    else:
        message = "Dados visíveis processados; builds ainda precisam de validação do patch"
    return {
        "screen_type": screen_type, "vision_status": vision_status, "detections": detections,
        "extracted": {"hero": hero or None, "hero_source": source, "enemies": enemy_heroes,
                      "owned_items": equipped, "enemy_items": enemy_equipped,
                      "cached": cached, "visual_age_seconds": visual_age},
        "recommendation": best, "recommendations": ranked["recommendations"], "message": message,
        "warning": "Scores são pesos, não confiança estatística; verifique versão dos itens e termos do jogo.",
    }
