"""Testes de integração do ciclo AO VIVO (provedor simulado, sem chamadas pagas)."""
import io
import uuid

import cv2
import numpy as np
import pytest
from fastapi.testclient import TestClient

import app as module
import vision_bridge

client = TestClient(module.app)


def photo_bytes():
    canvas = np.zeros((540, 960, 3), dtype=np.uint8)
    cv2.putText(canvas, "MATCH SCOREBOARD", (100, 100), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    return cv2.imencode(".jpg", canvas)[1].tobytes()


def analyze(session, flags=None):
    return client.post("/analyze", data={"session_id": session, "hero_hint": "hanzo", **(flags or {})},
                       files={"image": ("live.jpg", photo_bytes(), "image/jpeg")})


def setup_fake_online(monkeypatch, values):
    queue = list(values)
    monkeypatch.setattr(vision_bridge, "online_ready", lambda: True)

    async def mock_api(image, content_type="image/jpeg"):
        return vision_bridge.VisualState.model_validate(queue.pop(0))
    monkeypatch.setattr(vision_bridge, "read_visual_state", mock_api)


def state(screen="match_scoreboard", hero="hanzo", items=None, enemy_items=None, enemies=None):
    return {"screen_type": screen, "self_hero": hero, "enemies": enemies or [],
            "owned_items": items or [], "enemy_items": enemy_items or [], "note": "Teste visual"}


def test_live_scoreboard_armor_recommendation(monkeypatch):
    setup_fake_online(monkeypatch, [state(enemies=["Alpha", "Dyrroth"],
        enemy_items=["Antique Cuirass", "Dominance Ice"])])
    body = analyze(str(uuid.uuid4())).json()
    assert body["screen_type"] == "match_scoreboard"
    assert body["extracted"]["enemies"] == ["Alpha", "Dyrroth"]
    assert body["recommendation"]["item"] == "Malefic Roar"
    assert body["extracted"]["hero_source"] == "visual"


def test_live_gameplay_reuses_previous_scoreboard(monkeypatch):
    setup_fake_online(monkeypatch, [state(items=["Sea Halberd"], enemy_items=["Blade Armor", "Dominance Ice"]),
                                   state(screen="match_gameplay", hero=None)])
    session = str(uuid.uuid4())
    first = analyze(session).json()
    second = analyze(session).json()
    assert first["recommendation"]["item"] == "Malefic Roar"
    assert second["recommendation"]["item"] == "Malefic Roar"
    assert second["extracted"]["cached"] is True
    assert "Sea Halberd" in second["extracted"]["owned_items"]


def test_owned_items_are_not_recommended(monkeypatch):
    setup_fake_online(monkeypatch, [state(items=["Malefic Roar"], enemy_items=["Blade Armor", "Dominance Ice"])])
    body = analyze(str(uuid.uuid4())).json()
    assert body["recommendation"]["item"] != "Malefic Roar"


def test_post_match_does_not_recommend_or_keep_last_game(monkeypatch):
    setup_fake_online(monkeypatch, [state(enemy_items=["Blade Armor", "Dominance Ice"]),
                                   state(screen="post_match", hero=None),
                                   state(screen="match_gameplay", hero=None)])
    session = str(uuid.uuid4())
    assert analyze(session).json()["recommendation"]["item"] == "Malefic Roar"
    final = analyze(session).json()
    assert final["recommendation"] is None
    later = analyze(session).json()
    assert later["extracted"]["hero_source"] == "manual"
    assert later["extracted"]["enemy_items"] == []


def test_sessions_isolated(monkeypatch):
    setup_fake_online(monkeypatch, [state(items=["Sea Halberd"]), state(screen="match_gameplay", hero=None)])
    first = analyze(str(uuid.uuid4())).json()
    second = analyze(str(uuid.uuid4())).json()
    assert first["extracted"]["owned_items"] == ["Sea Halberd"]
    assert second["extracted"]["owned_items"] == []


def test_read_failure_fails_open_only_to_manual_not_fake_visual(monkeypatch):
    monkeypatch.setattr(vision_bridge, "online_ready", lambda: True)
    async def fail(*args):
        raise TimeoutError("private payload is not returned")
    monkeypatch.setattr(vision_bridge, "read_visual_state", fail)
    body = analyze(str(uuid.uuid4())).json()
    assert body["extracted"]["hero_source"] == "manual"
    assert body["extracted"]["enemy_items"] == []
    assert "falha" in body["vision_status"]
    assert "private payload" not in str(body)


def test_no_key_never_enables_online(monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("MLBB_VISION_ENABLED", "1")
    assert vision_bridge.online_ready() is False


def test_schema_rejects_invented_fields():
    with pytest.raises(Exception):
        vision_bridge.VisualState.model_validate({**state(), "win_rate": 99})


def test_real_user_supplied_images_are_accepted_with_no_fake_visual(monkeypatch):
    """Regressão de transporte com 3 prints; NÃO tenta passar prints finais por placares ao vivo."""
    from pathlib import Path
    monkeypatch.setattr(vision_bridge, "online_ready", lambda: False)
    monkeypatch.setattr(module, "TEMPLATES", Path(__file__).parent / "templates")
    sources = ["image.png", "image(1).png", "image(2).png"]
    data_dir = Path(__file__).parents[2]
    for file_name in sources:
        path = data_dir / file_name
        if not path.exists():
            pytest.skip("Imagens da conversa não incluídas no pacote distribuído")
        raw = path.read_bytes()
        response = client.post("/analyze", files={"image": (file_name, raw, "image/png")})
        # A captura grande é intencionalmente limitada a 2,5 MB.
        assert response.status_code in (200, 413)
        if response.status_code == 200:
            assert response.json()["extracted"]["hero_source"] == "desconhecido"
