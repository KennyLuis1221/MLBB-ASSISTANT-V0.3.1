"""Testes executáveis do backend: endpoint, autenticação e captura sintética."""
import io
import os
from pathlib import Path

import cv2
import numpy as np
from fastapi.testclient import TestClient

import app as module

client = TestClient(module.app)


def sample_image():
    canvas = np.random.default_rng(23).integers(0, 256, size=(150, 200, 3), dtype=np.uint8)
    return cv2.imencode(".png", canvas)[1].tobytes()


def test_health():
    assert client.get("/health").status_code == 200


def test_recommend_armor():
    result = client.post("/recommend", json={"hero": "hanzo", "enemy_armor_stacking": True})
    assert result.status_code == 200
    assert result.json()["recommendations"][0]["item"] == "Malefic Roar"


def test_recommend_no_unknown_hero():
    response = client.post("/recommend", json={"hero": "unknown_hero"})
    assert response.json()["recommendations"] == []


def test_analyze_without_template_uses_manual_hint(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "TEMPLATES", tmp_path)
    response = client.post("/analyze", data={"hero_hint": "hanzo", "enemy_healing_high": "true"},
                           files={"image": ("scene.png", sample_image(), "image/png")})
    assert response.status_code == 200
    body = response.json()
    assert body["detections"] == []
    assert body["extracted"]["hero_source"] == "manual"
    assert body["recommendation"]["item"] == "Sea Halberd"


def test_analyze_no_hero_no_hallucination(monkeypatch, tmp_path):
    monkeypatch.setattr(module, "TEMPLATES", tmp_path)
    response = client.post("/analyze", files={"image": ("scene.png", sample_image(), "image/png")})
    assert response.status_code == 200
    assert response.json()["recommendation"] is None


def test_analyze_real_template_match(monkeypatch, tmp_path):
    folder = tmp_path / "hero"
    folder.mkdir()
    rng = np.random.default_rng(42)
    template = rng.integers(0, 255, (40, 40, 3), dtype=np.uint8)
    template[10:25, 10:25] = (2, 60, 240)
    cv2.imwrite(str(folder / "hanzo.png"), template)
    canvas = rng.integers(0, 255, (160, 260, 3), dtype=np.uint8)
    canvas[60:100, 100:140] = template
    png = cv2.imencode(".png", canvas)[1].tobytes()
    monkeypatch.setattr(module, "TEMPLATES", tmp_path)
    response = client.post("/analyze", files={"image": ("screen.png", png, "image/png")})
    assert response.status_code == 200
    body = response.json()
    assert body["extracted"]["hero_source"] == "visual"
    assert body["extracted"]["hero"] == "hanzo"
    assert any(x["label"] == "hanzo" for x in body["detections"])


def test_reject_unsupported_type():
    response = client.post("/analyze", files={"image": ("bad.txt", b"abc", "text/plain")})
    assert response.status_code == 415


def test_api_token(monkeypatch):
    monkeypatch.setenv("MLBB_API_TOKEN", "unit-test-secret")
    assert client.post("/recommend", json={"hero": "hanzo"}).status_code == 401
    assert client.post("/recommend", headers={"Authorization": "Bearer unit-test-secret"},
                       json={"hero": "hanzo"}).status_code == 200
