"""Verifica contrato da chamada online sem fazer requests externos."""
import json
import httpx
import pytest

import vision_bridge


@pytest.mark.asyncio
async def test_provider_sends_image_and_json_schema(monkeypatch):
    monkeypatch.setenv("MLBB_VISION_ENABLED", "1")
    monkeypatch.setenv("OPENAI_API_KEY", "key-for-unit-test")
    capture = {}
    class MockResponse:
        def raise_for_status(self):
            pass
        def json(self):
            return {"output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps({
                "screen_type": "match_gameplay", "self_hero": None, "enemies": [],
                "owned_items": [], "enemy_items": [], "note": "Sem placar"
            })}]}]}
    class MockClient:
        def __init__(self, **kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, exc_type, exc, tb):
            return False
        async def post(self, url, json, headers):
            capture.update({"url": url, "json": json, "headers": headers})
            return MockResponse()
    monkeypatch.setattr(httpx, "AsyncClient", MockClient)
    result = await vision_bridge.read_visual_state(b"fake jpeg")
    assert result.screen_type == "match_gameplay"
    assert capture["json"]["store"] is False
    assert capture["json"]["text"]["format"]["strict"] is True
    assert capture["json"]["input"][0]["content"][1]["image_url"].startswith("data:image/jpeg;base64,")
    assert capture["headers"]["Authorization"] == "Bearer key-for-unit-test"
