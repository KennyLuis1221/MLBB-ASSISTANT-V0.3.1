# Templates visuais — precisarão ser calibrados com capturas reais

Diretórios reconhecidos pelo detector:

- `hero/hanzo.png`: recorte do retrato ou indicador de Hanzo da SUA interface.
- `enemy/dyrroth.png`: retrato do inimigo quando aparece no placar.
- `owned_item/malefic_roar.png`: ícone do item na região de inventário.

Imagens devem conter detalhes variados (não apenas cores chapadas), idealmente 30 a 100 px
na escala do JPEG que o Android envia (maior dimensão: 960 px). O código tenta escalas 85%,
100% e 115% e exige similaridade >=0.93, mas ainda não tem validação por região da tela.

A pasta começa SEM templates de jogo. A implementação consegue encontrar templates reais,
mas não consegue reconhecer heróis ou itens sem recortes calibrados. Não use o mockup gerado
por IA como fonte de dados reais ou para aferir a qualidade do reconhecimento.
