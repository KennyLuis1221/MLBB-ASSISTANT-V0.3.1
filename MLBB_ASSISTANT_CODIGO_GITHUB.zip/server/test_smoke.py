from app import MatchState, recommend

def test_armor():
    result = recommend(MatchState(hero='hanzo', enemy_armor_stacking=True))
    assert result['recommendations'][0]['item'] == 'Malefic Roar'

def test_healing():
    result = recommend(MatchState(hero='hanzo', enemy_healing_high=True))
    assert result['recommendations'][0]['item'] == 'Sea Halberd'

if __name__ == '__main__':
    test_armor(); test_healing(); print('2 smoke tests passed')
