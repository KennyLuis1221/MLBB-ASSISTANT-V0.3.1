"""Envia captura de teste ao backend. Uso: python replay_image.py caminho.png --url http://127.0.0.1:8000 --hero hanzo"""
import argparse
import json
import os
from pathlib import Path

import cv2
import httpx


def main():
    parser = argparse.ArgumentParser(description="Testa o reconhecimento de uma captura real antes do Android")
    parser.add_argument("image", type=Path)
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    parser.add_argument("--hero", default="", help="Herói manual, se não detectado")
    parser.add_argument("--token", default=os.getenv("MLBB_API_TOKEN", ""))
    args = parser.parse_args()
    im = cv2.imread(str(args.image))
    if im is None:
        parser.error("Não foi possível abrir a imagem")
    h, w = im.shape[:2]
    if max(h, w) > 1600:
        ratio = 1600 / max(h, w)
        im = cv2.resize(im, (round(w * ratio), round(h * ratio)))
    ok, jpg = cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 76])
    if not ok:
        parser.error("Falha ao converter a captura")
    with httpx.Client(timeout=45.0) as client:
        result = client.post(args.url.rstrip("/") + "/analyze",
            data={"hero_hint": args.hero},
            files={"image": ("capture.jpg", jpg.tobytes(), "image/jpeg")},
            headers={"Authorization": f"Bearer {args.token}"} if args.token else {})
    result.raise_for_status()
    print(json.dumps(result.json(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
