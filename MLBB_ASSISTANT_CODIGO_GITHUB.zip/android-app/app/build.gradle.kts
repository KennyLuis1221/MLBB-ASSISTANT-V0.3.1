plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mlbb.assistant"
    compileSdk = 35

    buildFeatures {
        buildConfig = true  // Necessário para BuildConfig.DEBUG no Android Gradle Plugin 8+
    }

    defaultConfig {
        applicationId = "com.mlbb.assistant"
        minSdk = 29
        targetSdk = 35
        versionCode = 4
        versionName = "0.3.1"
        manifestPlaceholders["cleartextTraffic"] = "false"
    }

    buildTypes {
        getByName("debug") {
            applicationIdSuffix = ".debug"
            manifestPlaceholders["cleartextTraffic"] = "true" // Somente debug: servidor HTTP na rede local
        }
        getByName("release") {
            isMinifyEnabled = false
            manifestPlaceholders["cleartextTraffic"] = "false" // Release exige HTTPS
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
