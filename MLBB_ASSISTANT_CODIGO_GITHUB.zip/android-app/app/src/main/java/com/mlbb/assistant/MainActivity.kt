package com.mlbb.assistant

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestProjection = 7301
    private lateinit var details: TextView
    private lateinit var urlField: EditText
    private lateinit var tokenField: EditText
    private lateinit var packageField: EditText
    private lateinit var heroField: EditText
    private lateinit var intervalField: EditText
    private lateinit var armorBox: CheckBox
    private lateinit var healingBox: CheckBox
    private lateinit var magicBox: CheckBox
    private lateinit var consentBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 19, 33)
        window.navigationBarColor = Color.rgb(8, 19, 33)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(30))
            setBackgroundColor(Color.rgb(8, 19, 33))
        }
        val root = ScrollView(this).apply { addView(layout) }
        setContentView(root)

        layout.addView(text("MLBB ASSISTANT", 27, 0xFFE9BC69.toInt(), true))
        layout.addView(text("V0.3 • Captura e visão online", 15, 0xFF35C7FF.toInt()))
        layout.addView(space(18))
        layout.addView(text("A visão online lê placares DURANTE a partida quando ativada no servidor. Builds ainda são demonstrativas e apenas Hanzo tem regras.", 14, 0xFFCDD8E7.toInt()))
        layout.addView(space(16))
        details = text("", 13, 0xFFE6EAF0.toInt())
        details.setPadding(dp(14), dp(12), dp(14), dp(12))
        details.background = gradient(0xFF10263D.toInt(), 0xFF152D41.toInt(), 14)
        layout.addView(details)
        layout.addView(space(14))

        layout.addView(button("1  Autorizar painel flutuante") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        layout.addView(space(8))
        layout.addView(button("2  Permitir reconhecer quando o MLBB está aberto") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        if (Build.VERSION.SDK_INT >= 33) {
            layout.addView(space(8))
            layout.addView(button("3  Permitir notificações") {
                if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
                } else toast("Notificações já permitidas")
            })
        }
        layout.addView(space(20))
        layout.addView(text("SERVIDOR DE ANÁLISE", 15, 0xFFE9BC69.toInt(), true))
        urlField = field("URL — ex.: http://192.168.1.50:8000", prefs.getString("url", "") ?: "")
        tokenField = field("Token do servidor (MLBB_API_TOKEN)", prefs.getString("token", "") ?: "").apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        packageField = field("Pacote do jogo", prefs.getString("game_package", "com.mobile.legends") ?: "com.mobile.legends")
        heroField = field("Herói escolhido (opcional, ex.: hanzo)", prefs.getString("hero_hint", "") ?: "")
        intervalField = field("Intervalo de análise em segundos (15 a 60)", prefs.getInt("interval", 25).toString())
        for (v in listOf(urlField, tokenField, packageField, heroField, intervalField)) {
            layout.addView(space(7))
            layout.addView(v)
        }
        layout.addView(space(14))
        layout.addView(text("CONTEXTO MANUAL PARA TESTES", 15, 0xFFE9BC69.toInt(), true))
        layout.addView(text("As regras de itens são demonstrativas para Hanzo. Seu herói pode ser identificado visualmente ou informado no campo acima.", 12, 0xFFB5C4D2.toInt()))
        armorBox = checkbox("Inimigos acumulando defesa física", prefs.getBoolean("armor", false))
        healingBox = checkbox("Inimigos com muita cura", prefs.getBoolean("healing", false))
        magicBox = checkbox("Inimigos com dano mágico explosivo", prefs.getBoolean("magic", false))
        listOf(armorBox, healingBox, magicBox).forEach { layout.addView(it) }
        layout.addView(space(12))
        consentBox = checkbox("Autorizo enviar capturas do jogo ao meu servidor e, se configurado, à IA online. Não envie telas pessoais.", false)
        layout.addView(consentBox)
        layout.addView(space(18))
        layout.addView(button("▶  Iniciar análise e painel") { startCapture() }, gold = true)
        layout.addView(space(8))
        layout.addView(button("■  Encerrar análise") {
            startService(Intent(this, ProjectionService::class.java).setAction(ProjectionService.ACTION_STOP))
            toast("Solicitado encerramento")
        })
        layout.addView(space(15))
        layout.addView(text("Privacidade: a sessão requer consentimento do Android. Capturas são enviadas à URL configurada, e podem ser encaminhadas ao provedor de IA pelo operador do servidor. Pause antes de abrir informações pessoais. Não há garantias contra troca de telas no exato instante de uma captura.", 12, 0xFFA7BDCB.toInt()))
    }

    override fun onResume() {
        super.onResume()
        if (::details.isInitialized) {
            details.text = "Painel: ${if (Settings.canDrawOverlays(this)) "PERMITIDO" else "SEM PERMISSÃO"}\n" +
                "Acesso de uso: ${if (hasUsageAccess()) "PERMITIDO" else "SEM PERMISSÃO"}\n" +
                "Análise: inicia somente com consentimento de tela"
        }
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun startCapture() {
        val url = urlField.text.toString().trim().trimEnd('/')
        if (!consentBox.isChecked) return toast("Confirme a autorização de envio de capturas nesta sessão")
        if (!Settings.canDrawOverlays(this)) return toast("Primeiro autorize o painel flutuante")
        if (!hasUsageAccess()) return toast("Primeiro permita acesso de uso: só capturaremos quando o jogo estiver aberto")
        if (!(url.startsWith("http://") || url.startsWith("https://"))) return toast("Digite URL http(s) do servidor")
        if (!BuildConfig.DEBUG && !url.startsWith("https://")) return toast("Build de produção exige HTTPS")
        if (tokenField.text.toString().isBlank()) return toast("Configure o token do servidor")
        val interval = intervalField.text.toString().toIntOrNull()
            ?: return toast("Intervalo deve ser um número (15 a 60)")
        if (interval !in 15..60) return toast("Escolha de 15 a 60 segundos")
        val gamePackage = packageField.text.toString().trim()
        if (gamePackage.isBlank() || !gamePackage.contains('.')) return toast("Informe o pacote Android do jogo")
        getSharedPreferences("settings", MODE_PRIVATE).edit()
            .putString("url", url)
            .putString("token", tokenField.text.toString().trim())
            .putString("game_package", gamePackage)
            .putString("hero_hint", heroField.text.toString().trim().take(60))
            .putInt("interval", interval)
            .putBoolean("armor", armorBox.isChecked)
            .putBoolean("healing", healingBox.isChecked)
            .putBoolean("magic", magicBox.isChecked)
            .apply()
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestProjection)
    }

    @Deprecated("Activity result is used here to avoid external library dependencies")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestProjection && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, ProjectionService::class.java)
                .setAction(ProjectionService.ACTION_START)
                .putExtra(ProjectionService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(ProjectionService.EXTRA_RESULT_DATA, data)
            startForegroundService(intent)
            toast("Análise iniciada. Abra o MLBB.")
        } else if (requestCode == requestProjection) toast("Captura não autorizada")
    }

    private fun field(hint: String, value: String): EditText = EditText(this).apply {
        setText(value)
        setSingleLine(true)
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF95ABBA.toInt())
        textSize = 14f
        setPadding(dp(13), dp(11), dp(13), dp(11))
        this.hint = hint
        background = gradient(0xFF142A3C.toInt(), 0xFF142A3C.toInt(), 10)
    }
    private fun checkbox(label: String, checked: Boolean): CheckBox = CheckBox(this).apply {
        text = label
        isChecked = checked
        setTextColor(0xFFE0EAF1.toInt())
        textSize = 13f
        buttonTintList = android.content.res.ColorStateList.valueOf(0xFF19B9FC.toInt())
    }
    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun button(label: String, action: () -> Unit, gold: Boolean = false): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(if (gold) 0xFF101D29.toInt() else Color.WHITE)
        background = gradient(if (gold) 0xFFE6B65A.toInt() else 0xFF16446A.toInt(),
            if (gold) 0xFFF3D28F.toInt() else 0xFF155178.toInt(), 12)
        setOnClickListener { action() }
    }
    private fun gradient(a: Int, b: Int, radius: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)
    ).apply { cornerRadius = dp(radius).toFloat() }
    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
}
