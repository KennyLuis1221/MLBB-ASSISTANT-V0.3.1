package com.mlbb.assistant

import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.UUID

data class AnalysisResult(
    val status: String,
    val item: String?,
    val reason: String,
    val detections: Int,
    val source: String,
    val hero: String?,
    val enemies: Int,
    val items: Int,
    val visionStatus: String
)

/** Envia somente JPEG reduzido; não armazena a captura no aparelho ou servidor. */
object UploadClient {
    fun analyze(
        baseUrl: String, token: String, jpeg: ByteArray, sessionId: String, heroHint: String,
        armor: Boolean, healing: Boolean, magic: Boolean
    ): AnalysisResult {
        val address = URL("${baseUrl.trimEnd('/')}/analyze")
        val conn = address.openConnection() as HttpURLConnection
        val boundary = "mlbb-${UUID.randomUUID()}"
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8_000
            conn.readTimeout = 40_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            conn.setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) conn.setRequestProperty("Authorization", "Bearer $token")
            DataOutputStream(conn.outputStream).use { out ->
                val fields = mapOf(
                    "hero_hint" to heroHint,
                    "session_id" to sessionId,
                    "enemy_armor_stacking" to armor.toString(),
                    "enemy_healing_high" to healing.toString(),
                    "enemy_magic_burst" to magic.toString()
                )
                for ((name, value) in fields) {
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(StandardCharsets.UTF_8))
                }
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"image\"; filename=\"frame.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray(StandardCharsets.UTF_8))
                out.write(jpeg)
                out.write("\r\n--$boundary--\r\n".toByteArray(StandardCharsets.UTF_8))
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                val payload = conn.errorStream?.bufferedReader()?.readText()?.take(180) ?: ""
                throw IllegalStateException("HTTP $code: $payload")
            }
            val response = JSONObject(conn.inputStream.bufferedReader().readText())
            val detected = response.optJSONArray("detections")?.length() ?: 0
            val recommendation = response.optJSONObject("recommendation")
            val extracted = response.optJSONObject("extracted")
            val readSource = extracted?.optString("hero_source", "desconhecido") ?: "desconhecido"
            return AnalysisResult(
                status = response.optString("message", "Imagem enviada"),
                item = recommendation?.optString("item")?.takeIf { it.isNotBlank() },
                reason = recommendation?.optString("reason")
                    ?: response.optString("message", "Nenhuma recomendação disponível"),
                detections = detected,
                source = "Fonte: $readSource • " + (recommendation?.optString("source", "sem recomendação") ?: "sem recomendação"),
                hero = extracted?.optString("hero")?.takeIf { it.isNotBlank() && it != "null" },
                enemies = extracted?.optJSONArray("enemies")?.length() ?: 0,
                items = extracted?.optJSONArray("owned_items")?.length() ?: 0,
                visionStatus = response.optString("vision_status", "sem visão online")
            )
        } finally {
            conn.disconnect()
        }
    }
}
