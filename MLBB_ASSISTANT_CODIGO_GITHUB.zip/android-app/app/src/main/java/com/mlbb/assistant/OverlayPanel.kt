package com.mlbb.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Painel sobreposto: somente a área visível recebe toques; o restante da partida continua interativo. */
class OverlayPanel(
    private val context: Context,
    private val onPause: () -> Unit,
    private val onStop: () -> Unit
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var attached = false
    private var expanded = false
    private var paused = false
    private val surface = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(8), dp(7), dp(8), dp(7))
        background = background()
        elevation = dp(8).toFloat()
    }
    private val heading = line("M", 18, 0xFFEAC275.toInt(), true)
    private val content = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(7), dp(9), dp(7), dp(5))
    }
    private val status = line("Aguardando MLBB...", 12, 0xFFB6C9DB.toInt())
    private val item = line("Ainda sem recomendação", 17, 0xFFEBCB82.toInt(), true)
    private val reason = line("Abra o placar durante a partida para detectar as builds.", 12, 0xFFE9EEF4.toInt())
    private val counts = line("", 11, 0xFF6EE2BD.toInt())
    private lateinit var pauseButton: Button
    private val params = WindowManager.LayoutParams(
        dp(57), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_SECURE, // evita que dados do próprio painel sejam recapturados
        android.graphics.PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.END
        x = dp(8)
        y = dp(90)
    }

    fun show() {
        if (attached) return
        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(heading)
            setOnClickListener { toggle() }
        }
        header.setOnTouchListener(DragHandler())
        surface.addView(header)
        content.addView(line("VISÃO ONLINE • TESTE", 13, 0xFF35C7FF.toInt(), true))
        content.addView(status)
        content.addView(space(9))
        content.addView(line("PRÓXIMO ITEM", 11, 0xFFB5C8D8.toInt(), true))
        content.addView(item)
        content.addView(reason)
        content.addView(space(7))
        content.addView(counts)
        val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        pauseButton = button("Pausar") {
            paused = !paused
            pauseButton.text = if (paused) "Retomar" else "Pausar"
            onPause()
        }
        actions.addView(pauseButton, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(button("Encerrar") { onStop() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        content.addView(actions)
        surface.addView(content)
        content.visibility = View.GONE
        wm.addView(surface, params)
        attached = true
    }

    private fun toggle() {
        expanded = !expanded
        heading.text = if (expanded) "MLBB ASSISTANT  •  −" else "M"
        content.visibility = if (expanded) View.VISIBLE else View.GONE
        params.width = dp(if (expanded) 306 else 57)
        if (attached) wm.updateViewLayout(surface, params)
    }

    fun showStatus(message: String) {
        status.text = message.take(220)
    }

    fun showResult(result: AnalysisResult) {
        status.text = result.status
        item.text = result.item ?: "Aguardando informações"
        reason.text = result.reason.take(240)
        counts.text = "${result.visionStatus}\nHerói: ${result.hero ?: "não identificado"} • Inimigos: ${result.enemies} • Itens: ${result.items}\n${result.source}"
    }

    fun remove() {
        if (attached) {
            wm.removeView(surface)
            attached = false
        }
    }

    private inner class DragHandler : View.OnTouchListener {
        private var initialX = 0
        private var initialY = 0
        private var downX = 0f
        private var downY = 0f
        private var didMove = false
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    downX = event.rawX; downY = event.rawY
                    didMove = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(7) || kotlin.math.abs(dy) > dp(7)) didMove = true
                    if (didMove) {
                        // Como Gravity.END está ativo, arrastar para a direita reduz x.
                        params.x = (initialX - dx).coerceAtLeast(0)
                        params.y = (initialY + dy).coerceAtLeast(0)
                        if (attached) wm.updateViewLayout(surface, params)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    if (!didMove) toggle()
                    return true
                }
            }
            return false
        }
    }

    private fun background() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(0xF50A1624.toInt(), 0xF2173047.toInt())
    ).apply {
        cornerRadius = dp(15).toFloat()
        setStroke(dp(1), 0xFFD6AC65.toInt())
    }
    private fun line(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(context).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(3), dp(3), dp(3), dp(4))
    }
    private fun button(value: String, action: () -> Unit) = Button(context).apply {
        text = value
        isAllCaps = false
        textSize = 11f
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
    }
    private fun space(h: Int) = View(context).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }
    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
}
