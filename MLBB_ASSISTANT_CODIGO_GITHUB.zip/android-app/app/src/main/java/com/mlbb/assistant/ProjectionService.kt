package com.mlbb.assistant

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/**
 * Serviço de captura: consentimento Android obrigatório a CADA sessão.
 * Só transmite JPEG quando confirma que o pacote MLBB é a última atividade retomada.
 * Sem leitura de memória, sem controle do jogo, sem persistir capturas.
 */
class ProjectionService : Service() {
    companion object {
        const val ACTION_START = "com.mlbb.assistant.START"
        const val ACTION_STOP = "com.mlbb.assistant.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "mlbb_capture"
        private const val NOTIFICATION_ID = 37
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayPanel? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private val ui = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val uploadInFlight = AtomicBoolean(false)
    private var paused = false
    private var lastUploadAt = 0L
    private var intervalMs = 25_000L
    private var sessionId = UUID.randomUUID().toString()
    private var url = ""
    private var token = ""
    private var gamePackage = "com.mobile.legends"
    private var heroHint = ""
    private var armor = false
    private var healing = false
    private var magic = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            ui.post { showStatus("Captura interrompida pelo Android"); stopSelf() }
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            // Reutiliza a MESMA sessão; Android 14+ proíbe criar uma segunda projeção com mesmo token.
            ui.post { resizeSurface(width, height) }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START || projection != null) return START_NOT_STICKY
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        if (resultCode == 0 || resultData == null || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        url = prefs.getString("url", "") ?: ""
        token = prefs.getString("token", "") ?: ""
        gamePackage = prefs.getString("game_package", "com.mobile.legends") ?: "com.mobile.legends"
        heroHint = prefs.getString("hero_hint", "") ?: ""
        intervalMs = prefs.getInt("interval", 25).toLong().coerceIn(15, 60) * 1000L
        sessionId = UUID.randomUUID().toString()
        armor = prefs.getBoolean("armor", false)
        healing = prefs.getBoolean("healing", false)
        magic = prefs.getBoolean("magic", false)

        makeNotificationChannel()
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification())
            }
            overlay = OverlayPanel(this, onPause = {
                paused = !paused
                showStatus(if (paused) "Envio pausado" else "Envio retomado")
            }, onStop = { stopSelf() }).also { it.show() }
            captureThread = HandlerThread("MLBB-capture").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            projection!!.registerCallback(projectionCallback, ui)
            val size = android.graphics.Point()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(size)
            resizeSurface(size.x, size.y)
            showStatus("Aguardando MLBB em primeiro plano")
        } catch (error: Exception) {
            showStatus("Falha de captura: ${error.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun resizeSurface(width: Int, height: Int) {
        if (width <= 0 || height <= 0 || projection == null) return
        if (reader?.width == width && reader?.height == height) return
        val newReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener({ r -> captureFrame(r) }, captureHandler)
        val oldReader = reader
        val virtual = display
        if (virtual == null) {
            val density = resources.displayMetrics.densityDpi
            display = projection?.createVirtualDisplay(
                "MLBB Assist Capture", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, captureHandler
            )
        } else {
            virtual.resize(width, height, resources.displayMetrics.densityDpi)
            virtual.surface = newReader.surface
        }
        reader = newReader
        oldReader?.setOnImageAvailableListener(null, null)
        oldReader?.close()
    }

    private fun captureFrame(imageReader: ImageReader) {
        val image = try { imageReader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            if (paused || uploadInFlight.get()) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastUploadAt < intervalMs) return
            // Evita consultar UsageStats dezenas de vezes por segundo enquanto jogo está fechado.
            lastUploadAt = now
            if (!isGameForeground()) {
                showStatus("Envio bloqueado: abra o MLBB")
                return
            }
            if (!uploadInFlight.compareAndSet(false, true)) return
            val jpeg = try { encodeJpeg(image) } catch (_: Exception) { null }
            if (jpeg == null) {
                uploadInFlight.set(false)
                showStatus("Falha ao converter quadro")
                return
            }
            executor.execute {
                try {
                    // Valida de novo imediatamente antes do upload; não é garantia atômica ao trocar de app.
                    if (paused || !isGameForeground()) return@execute
                    val result = UploadClient.analyze(url, token, jpeg, sessionId, heroHint, armor, healing, magic)
                    ui.post { overlay?.showResult(result) }
                } catch (error: Exception) {
                    val detail = error.message?.take(120) ?: error.javaClass.simpleName
                    showStatus("Servidor: $detail")
                } finally {
                    uploadInFlight.set(false)
                }
            }
        } finally {
            image.close()
        }
    }

    private fun encodeJpeg(image: android.media.Image): ByteArray {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        require(pixelStride == 4) { "Formato RGBA inesperado" }
        val paddedWidth = rowStride / pixelStride
        val paddedBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        plane.buffer.rewind()
        paddedBitmap.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, image.width, image.height)
        val ratio = (1600f / max(image.width, image.height)).coerceAtMost(1f)
        val newWidth = (image.width * ratio).toInt().coerceAtLeast(1)
        val newHeight = (image.height * ratio).toInt().coerceAtLeast(1)
        val finalBitmap = Bitmap.createScaledBitmap(cropped, newWidth, newHeight, true)
        val output = ByteArrayOutputStream()
        finalBitmap.compress(Bitmap.CompressFormat.JPEG, 76, output)
        if (finalBitmap !== cropped) finalBitmap.recycle()
        if (cropped !== paddedBitmap) cropped.recycle()
        paddedBitmap.recycle()
        return output.toByteArray()
    }

    /** Sem acesso de uso ou com outro aplicativo em foco: NÃO envia nenhum frame. */
    private fun isGameForeground(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) return false
        val ops = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        if (ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
            != AppOpsManager.MODE_ALLOWED) return false
        val usage = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usage.queryEvents(now - 6 * 60 * 60 * 1000L, now)
        val item = UsageEvents.Event()
        var foregroundPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(item)
            if (item.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                item.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                foregroundPackage = item.packageName
            }
        }
        return foregroundPackage == gamePackage
    }

    private fun showStatus(message: String) {
        ui.post { overlay?.showStatus(message) }
    }

    private fun makeNotificationChannel() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "MLBB — Captura ativa", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(): Notification {
        val stopIntent = Intent(this, ProjectionService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 100, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(this, 101, openIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(com.mlbb.assistant.R.drawable.ic_assistant)
            .setContentTitle("MLBB ASSISTANT ativo")
            .setContentText("Captura autorizada; envio apenas quando MLBB está em foco")
            .setContentIntent(openPending)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Encerrar", stopPending).build())
            .build()
    }

    override fun onDestroy() {
        overlay?.remove()
        overlay = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close(); reader = null
        display?.release(); display = null
        val stoppedProjection = projection
        projection = null
        stoppedProjection?.unregisterCallback(projectionCallback)
        stoppedProjection?.stop()
        captureThread?.quitSafely(); captureThread = null
        executor.shutdownNow()
        super.onDestroy()
    }
}
